from django.apps import AppConfig


class AppDeTomasConfig(AppConfig):
    name = 'app_de_tomas'
