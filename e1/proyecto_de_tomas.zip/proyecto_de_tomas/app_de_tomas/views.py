from django.shortcuts import render

# Create your views here.
def index(request):
	return render(request,'app_de_tomas/index.html')

def bienvenida(request):
	return render(request,'app_de_tomas/bienvenida.html')

def tarea(request):
	return render(request,'app_de_tomas/tarea.html')	


