from django.shortcuts import render


def formulario(request):
    return render(request, 'app/formulario.html')

def resultado(request):
    dato_nombre = request.POST['nombre']
    dato_rut = request.POST['rut']
    dato_email = request.POST['email']
    dato_siono = request.POST['siono']
    contexto = {"nombre":dato_nombre, "rut":dato_rut, "email":dato_email, "siono":dato_siono}
    return render(request, 'app/resultado.html', contexto)
