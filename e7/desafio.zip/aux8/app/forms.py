from django import forms

class formulario_nuevocurso(forms.Form):
	semestre= forms.CharField(label='Ingrese semestre', widget= forms.TextInput(attrs={'class':'form-control',}))
	
	departamento= forms.CharField(label='Ingrese departamento', widget= forms.TextInput(attrs={'class':'form-control',}))
	
	anho= forms.IntegerField(label='Ingrese año', widget= forms.TextInput(attrs={'class':'form-control','type':'number'}))
	
	horario= forms.CharField(label='Ingrese horario', widget= forms.TextInput(attrs={'class':'form-control',}))
	
	nombre= forms.CharField(label='Ingrese nombre', widget= forms.TextInput(attrs={'class':'form-control',}))
	
	codigo= forms.CharField(label='Ingrese código', widget= forms.TextInput(attrs={'class':'form-control',}))
	
	ud= forms.IntegerField(label='Ingrese ud', widget= forms.TextInput(attrs={'class':'form-control','type':'number'}))
	
	
	
class formulario_updateud(forms.Form):
	codigo= forms.CharField(label='Ingrese código del curso', widget= forms.TextInput(attrs={'class':'form-control',}))
	ud= forms.IntegerField(label='Ingrese nueva cantidad de ud', widget= forms.TextInput(attrs={'class':'form-control','type':'number'}))
	
	
class formulario_eliminar(forms.Form):
	semestre= forms.CharField(label='Ingrese el semestre que desea borrar', widget= forms.TextInput(attrs={'class':'form-control',}))




	

# Create your models here.
