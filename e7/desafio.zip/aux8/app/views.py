from django.shortcuts import render
from .forms import formulario_nuevocurso
from .forms import formulario_updateud
from .forms import formulario_eliminar
from django.http import HttpResponse, HttpResponseRedirect
from django.core.files.storage import FileSystemStorage

def index(request):
	return render(request,'app/index.html')
	
def agregar(request):
	form=formulario_nuevocurso()
	info={'titulo':'Agregar curso','form':form}
	return render(request,'app/agregar.html', info)
	
def agregado(request):
	new_curso=cursos(semestre=request.POST['semestre'], departamento=request.POST['departamento'], anho=request.POST['anho'], horario=request.POST['horario'], nombre=request.POST['nombre'], codigo=request.POST['codigo'], ud=request.POST['ud'])
	new_curso.save()
	context={'titulo':'Formulario correcto', 'comentario':'Gracias'}
	return render(request,'app/agregado.html', context)
	
def updateud(request):
	form=formulario_updateud()
	info={'titulo':'Actualizar ud','form':form}
	return render(request,'app/updateud.html', info)
	
def updateok(request):
	curso=cursos.objects.get(codigo=request.POST['codigo'])
	curso.ud=request.POST['ud']
	curso.save()
	context={'titulo':'Información actualizada', 'comentario':'Gracias'}
	return render(request, 'app/updateok.html',context)
	
def borrar(request):
	form=formulario_eliminar()
	info={'titulo':'Eliminar ramos del semestre','form':form}
	return render(request,'app/borrar.html', info)

def borrado(request):
	curso=cursos.objects.get(semestre=request.POST['semestre'])
	curso.delete()
	context={'titulo':'Cursos eliminados'}
	return render(request, 'app/borrado.html',context)


def cursos(request):
	contexto = {}
	contexto['cursosp'] = cursos.objects.get(semestre='primavera')
	contexto['cursoso'] = cursos.objects.get(semestre='otoño')
	return render(request, 'app/cursos.html', contexto)
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
