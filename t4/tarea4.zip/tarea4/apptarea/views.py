from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse, HttpResponseRedirect
from django.core.files.storage import FileSystemStorage

# Create your views here.

def index(request):
	return render(request,'apptarea/index.html')

def quienessomos(request):
	return render(request,'apptarea/quienessomos.html')

def carta(request):
	return render(request,'apptarea/carta.html')	

def pedidos(request):
	return render(request,'apptarea/pedidos.html')

def sugerencias(request):
	return render(request,'apptarea/sugerencias.html')
	
def faq(request):
	return render(request,'apptarea/faq.html')

def resultado(request):
    dato_nombre = request.POST['nombre']
    dato_sugerencia = request.POST['sugerencia']
    dato_email = request.POST['email']
    contexto = {"nombre":dato_nombre, "sugerencia":dato_sugerencia, "email":dato_email}
    return render(request, 'apptarea/resultado.html', contexto)
    

def consulta(request):
	contexto={}
	contexto['boleta']=PlatosDeBoleta.objects.all()
	return render(request,'apptarea/consulta.html', contexto)
	
def loginView(request):
    username = request.POST.get('username')
    password = request.POST.get('password')

    user = authenticate(username=username, password=password)
    if user is not None:
        login(request,user)
        context= {'mensaje':' '}
    else:
    	context= {'mensaje':'Error de login. Usuario o contraseña incorrecta.'}
    return render(request, 'apptarea/login.html', context)

def logoutView(request):
    logout(request)
    context= {'mensaje':' '}
    return redirect('/')
