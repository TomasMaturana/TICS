from django.apps import AppConfig


class ApptareaConfig(AppConfig):
    name = 'apptarea'
