from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = 'app_de_in3501'
